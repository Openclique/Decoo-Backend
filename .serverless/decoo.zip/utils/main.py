from get_geohashes_in_radius import getGeohashesInRadius

print(getGeohashesInRadius(34.0194, -118.411, 20))