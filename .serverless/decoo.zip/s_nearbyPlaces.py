import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='decoo',
    application_name='decoo',
    app_uid='1gL63Dsrs3hHpt5Np2',
    org_uid='b91530ba-3651-4caa-b555-b124bfe98f05',
    deployment_uid='6c2385f4-e818-4f6a-999d-221163945529',
    service_name='decoo',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='test',
    plugin_version='5.4.3',
    disable_frameworks_instrumentation=False,
    serverless_platform_stage='prod'
)
handler_wrapper_kwargs = {'function_name': 'decoo-test-nearbyPlaces', 'timeout': 6}
try:
    user_handler = serverless_sdk.get_user_handler('places.nearby')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
